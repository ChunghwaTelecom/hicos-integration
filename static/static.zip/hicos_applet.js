(function (angular) {
    angular.module("HiCosAppletModule", []);

    angular.module("HiCosAppletModule")
        .factory('hiCosApplet', ['$q', hiCosApplet]);

    var hiCosApplet = function ($q) {

        var attributes = {
            id: 'loginApplet',
            code: 'com.chttl.sac.pki.applet.HiCOSLoginApplet',
            width: 0,
            height: 0
        };

        var parameters = {
            jnlp_href: './certification/HiCOSLoginApplet.jnlp', // FIXME 不要用相對路徑
            separate_jvm: 'true',
            java_status_events: 'true',
            permissions: 'all-permissions'
        };

        var applet;

        $(document.body).append("<div id='applet'></div>");
        var appletTag = deployJava.getApplet(attributes, parameters, '1.5');
        $("#applet").html(appletTag);

        applet = document.loginApplet;

        function promisify(appletFunction, receiver) {
            // Taken from https://github.com/rangle/angular-promisify/blob/master/src/denodeify.js
            return function () {
                var args = Array.prototype.slice.call(arguments, 0);
                var context = receiver || this;
                return $q(function (resolve, reject) {
                    var callback = function (error, result) {
                        if (error) {
                            reject(error);
                        } else {
                            var code = applet.getHandleCode();
                            var message = applet.getHandleMessage();
                            resolve({
                                code: code,
                                message: message,
                                value: result
                            });
                        }
                    };
                    args.push(callback);

                    appletFunction.apply(context, args);
                });
            };
        }

        return {
            getVersionInfo: promisify(applet.getVersionInfo),
            getSlotIdListWithToken: promisify(applet.getSlotIdListWithToken),
            getSlotInfoWithToken: promisify(applet.getSlotInfoWithToken),
            getTokenInfo: promisify(applet.getTokenInfo),
            getTokenId: promisify(applet.getTokenId),
            getPemX509Certificate: promisify(applet.getPemX509Certificate),
            getPemSignatureCertificate: promisify(applet.getPemSignatureCertficate),
            getPemEncryptedCertificate: promisify(applet.getPemEncryptedCertficate),
            getJsonX509Certificate: promisify(applet.getJsonX509Certificate),
            getJsonSignatureCertificate: promisify(applet.getJsonSignatureCertficate),
            getJsonEncryptedCertificate: promisify(applet.getJsonEncryptedCertficate),
            checkLoginValid: promisify(applet.checkLoginValid),
            makePemLoginSignedMessage: promisify(applet.makePemLoginSignedMessage),
            verifySignature: promisify(applet.verifySignature),
            getLoginInfoFromPemSignedData: promisify(applet.getLoginInfoFromPemSignedData),
            makeBase64PKCS1Signature: promisify(applet.makeBase64PKCS1Signature),
            verifyBase64PKCS1Signature: promisify(applet.verifyBase64PKCS1Signature),
            makeBase64PKCS1RawData: promisify(applet.makeBase64PKCS1RawData),
            decryptBase64PKCS1RawData: promisify(applet.decryptBase64PKCS1RawData),
            makePKCS7EnvelopedData: promisify(applet.makePKCS7EnvelopedData),
            decryptPemPKCS7EnvelopedData: promisify(applet.decryptPemPKCS7EnvelopedData)
        };
    };

})(angular);
